JARVIS BY IMMORTAL PRINCE:-

Packages:

pip install SpeechRecognition
pip install pyttsx3
pip install pywhatkit

------------------------------------------

additional:

pip3 install beautifulsoup4

pip3 install googletrans

pip3 install gTTS

pip3 install gTTS-token

pip3 install pip

pip3 install pipwin

pip3 install playsound

pip3 install PyAudio

pip3 install pylint

pip3 install pyobjc

pip3 install pyttsx3

pip3 install setuptools

pip3 install SpeechRecognition

pip3 install Translator

brew install flac

brew install portaudio